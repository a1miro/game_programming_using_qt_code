#include "scaleitem.h"

#include <QPainter>
#include <QStyleOptionGraphicsItem>

ScaleItem::ScaleItem(QGraphicsItem *parent)
    : QGraphicsRectItem(parent)
{
}

void ScaleItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget)

    const QPen oldPen = painter->pen();

    const QRectF r = rect();

    const qreal detail = option->levelOfDetailFromTransform(painter->worldTransform());
    const QColor fillColor = (detail >= 5) ? Qt::yellow : Qt::red;

    const qreal square = r.width() / 10;
    painter->fillRect(QRectF(0, 0, square, square), fillColor);
    painter->fillRect(QRectF(r.width() - square, 0, square, square), fillColor);
    painter->fillRect(QRectF(0,r.height() - square, square, square), fillColor);
    painter->fillRect(QRectF(r.width() - square, r.height() - square, square, square), fillColor);

    painter->setPen(Qt::black);
    painter->drawRect(r);
    painter->drawLine(r.topLeft(), r.bottomRight());
    painter->drawLine(r.topRight(), r.bottomLeft());
    const qreal padding = r.width() / 4;
    painter->drawRect(r.adjusted(padding, padding, -padding, -padding));

    painter->setPen(oldPen);
}
