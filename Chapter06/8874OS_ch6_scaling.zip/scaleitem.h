#ifndef SCALEITEM_H
#define SCALEITEM_H

#include <QGraphicsRectItem>

class ScaleItem : public QGraphicsRectItem
{

public:
    ScaleItem(QGraphicsItem *parent = 0);

public:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // SCALEITEM_H
