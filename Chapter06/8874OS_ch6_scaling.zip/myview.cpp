#include "myview.h"

#include <QWheelEvent>
#include <QScrollBar>

MyView::MyView(QWidget *parent)
    : QGraphicsView(parent)
    , m_lastMousePos(0, 0)
    , m_pressed(false)
{
    setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
}

void MyView::wheelEvent(QWheelEvent *event)
{
    const qreal factor = 1.1;
    if (event->angleDelta().y() > 0)
        scale(factor, factor);
    else
        scale(1/factor, 1/factor);
}


void MyView::mouseMoveEvent(QMouseEvent *event)
{
    if (!m_pressed)
        return QGraphicsView::mouseMoveEvent(event);

    QPoint diff = m_lastMousePos - event->pos();
    if (QScrollBar *hbar = horizontalScrollBar())
        hbar->setValue(hbar->value() + diff.x());
    if (QScrollBar *vbar = verticalScrollBar())
        vbar->setValue(vbar->value() + diff.y());
    m_lastMousePos = event->pos();
}

void MyView::mousePressEvent(QMouseEvent *event)
{
    if (Qt::LeftButton == event->button()) {
        m_pressed = true;
        m_lastMousePos = event->pos();
    } else {
        QGraphicsView::mousePressEvent(event);
    }
}

void MyView::mouseReleaseEvent(QMouseEvent *event)
{
    if (Qt::LeftButton == event->button())
        m_pressed = false;
    else
        QGraphicsView::mouseReleaseEvent(event);
}
