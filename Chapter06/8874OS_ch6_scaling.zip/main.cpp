#include <QApplication>
#include <QGraphicsScene>

#include "myview.h"
#include "scaleitem.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QGraphicsScene scene;
    ScaleItem *item = new ScaleItem;
    item->setRect(0, 0, 500, 500);
    scene.addItem(item);

    MyView view;
    view.setScene(&scene);
    view.show();

    return a.exec();
}
