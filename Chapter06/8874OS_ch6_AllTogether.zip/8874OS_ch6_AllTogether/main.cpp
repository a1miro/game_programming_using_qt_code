#include <QApplication>
#include <QGraphicsView>
#include <QGraphicsRectItem>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QGraphicsScene scene;

    scene.addEllipse(QRectF(0, 0, 100, 100), QColor(0, 0, 0));

    QGraphicsLineItem *line = scene.addLine(0, 50, 100, 50, QColor(0, 0, 255));
    const qreal shift = line->pen().widthF() / 2.0;  // <- For antialiasing
    line->moveBy(-shift, -shift);  // <- For antialiasing

    QGraphicsRectItem *item = scene.addRect(0, 0, 25, 25, Qt::NoPen, Qt::red);
    item->setPos(scene.sceneRect().center() - item->rect().center());

    QGraphicsView view;
    view.setRenderHint(QPainter::Antialiasing);  // <- For antialiasing
    view.setScene(&scene);
    view.show();

    return app.exec();
}
