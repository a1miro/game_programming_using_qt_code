#include <QtGui>
#include <QtWidgets>

class BlackRectangle : public QGraphicsItem
{
public:
    explicit BlackRectangle(QGraphicsItem *parent = 0)
        : QGraphicsItem(parent)
        , m_rect(0, 0, 75, 25) {
        setFlag(QGraphicsItem::ItemIsSelectable, true);
    }

    virtual ~BlackRectangle() {}

    QRectF boundingRect() const {
        return m_rect;
    }

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
        Q_UNUSED(widget)
        if (option->state & QStyle::State_Selected)
            painter->fillRect(boundingRect(), Qt::red);
        else
            painter->fillRect(boundingRect(), Qt::black);
    }

    QRectF rect() const {
        return m_rect;
    }

    void setRect(const QRectF& rect) {
        if (rect == m_rect)
            return;
        prepareGeometryChange();
        m_rect = rect;
    }

private:
    QRectF m_rect;
};


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QGraphicsScene scene;

    BlackRectangle *normalItem = new BlackRectangle;
    scene.addItem(normalItem);

    BlackRectangle *bigItem = new BlackRectangle;
    bigItem->setRect(QRectF(100, 50, 100, 100));
    scene.addItem(bigItem);

    QGraphicsView view;
    view.setScene(&scene);
    view.show();

    return app.exec();
}

