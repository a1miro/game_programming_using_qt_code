#include <QtGui>
#include <QtWidgets>

class ScaleItem : public QGraphicsRectItem
{

public:
    ScaleItem(QGraphicsItem *parent = 0)
        : QGraphicsRectItem(parent)
    {
    }

public:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        Q_UNUSED(widget)

        const QPen oldPen = painter->pen();

        const QRectF r = rect();

        const qreal detail = option->levelOfDetailFromTransform(painter->worldTransform());
        const QColor fillColor = (detail >= 5) ? Qt::yellow : Qt::red;

        const qreal square = r.width() / 10;
        painter->fillRect(QRectF(0, 0, square, square), fillColor);
        painter->fillRect(QRectF(r.width() - square, 0, square, square), fillColor);
        painter->fillRect(QRectF(0,r.height() - square, square, square), fillColor);
        painter->fillRect(QRectF(r.width() - square, r.height() - square, square, square), fillColor);

        QPen p(Qt::black);
        p.setCosmetic(true);
        painter->setPen(p);
        painter->drawRect(r);
        painter->drawLine(r.topLeft(), r.bottomRight());
        painter->drawLine(r.topRight(), r.bottomLeft());
        const qreal padding = r.width() / 4;
        painter->drawRect(r.adjusted(padding, padding, -padding, -padding));

        painter->setPen(oldPen);
    }
};

class MyView : public QGraphicsView
{
    Q_OBJECT
public:
    explicit MyView(QWidget *parent = 0)
        : QGraphicsView(parent)
        , m_lastMousePos(0, 0)
        , m_pressed(false)
    {
        setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    }

protected:
    virtual void wheelEvent(QWheelEvent *event)
    {
        const qreal factor = 1.1;
        if (event->angleDelta().y() > 0)
            scale(factor, factor);
        else
            scale(1/factor, 1/factor);
    }

    virtual void mouseMoveEvent(QMouseEvent *event)
    {
        if (!m_pressed)
            return QGraphicsView::mouseMoveEvent(event);

        QPoint diff = m_lastMousePos - event->pos();
        if (QScrollBar *hbar = horizontalScrollBar())
            hbar->setValue(hbar->value() + diff.x());
        if (QScrollBar *vbar = verticalScrollBar())
            vbar->setValue(vbar->value() + diff.y());
        m_lastMousePos = event->pos();
    }

    virtual void mousePressEvent(QMouseEvent *event)
    {
        if (Qt::LeftButton == event->button()) {
            m_pressed = true;
            m_lastMousePos = event->pos();
        } else {
            QGraphicsView::mousePressEvent(event);
        }
    }

    virtual void mouseReleaseEvent(QMouseEvent *event)
    {
        if (Qt::LeftButton == event->button())
            m_pressed = false;
        else
            QGraphicsView::mouseReleaseEvent(event);
    }

private:
    QPoint m_lastMousePos;
    bool m_pressed;
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QGraphicsScene scene;
    ScaleItem *item = new ScaleItem;
    item->setRect(0, 0, 500, 500);
    scene.addItem(item);

    MyView view;
    view.setScene(&scene);
    view.show();

    return a.exec();
}

#include "main.moc"
