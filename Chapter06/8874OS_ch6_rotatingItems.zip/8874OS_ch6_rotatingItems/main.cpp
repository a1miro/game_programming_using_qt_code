#include <QtGui>
#include <QtWidgets>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QGraphicsScene scene;

    QGraphicsRectItem *rectA = new QGraphicsRectItem(0,0,45,45);
    QGraphicsRectItem *rectB = new QGraphicsRectItem(0,0,45,45);
    QGraphicsRectItem *rectC = new QGraphicsRectItem(0,0,45,45);
    QGraphicsRectItem *rectD = new QGraphicsRectItem(0,0,45,45);
    rectB->moveBy(50,0);
    rectC->moveBy(0,50);
    rectD->moveBy(50,50);

    QGraphicsItemGroup *group = new QGraphicsItemGroup;
    group->addToGroup(rectA);
    group->addToGroup(rectB);
    group->addToGroup(rectC);
    rectD->setGroup(group);

    group->setRotation(70);

    rectA->setRotation(-25);
    rectB->setRotation(-25);
    rectC->setRotation(-25);
    rectD->setRotation(-25);

    scene.addItem(group);

    QGraphicsView view;
    view.setScene(&scene);
    view.show();

    return app.exec();
}

