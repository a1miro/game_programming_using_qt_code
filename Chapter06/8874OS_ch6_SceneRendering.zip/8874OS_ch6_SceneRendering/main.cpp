#include <QtGui>
#include <QtWidgets>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QGraphicsScene scene;
    QGraphicsRectItem *rectItem = new QGraphicsRectItem();
    rectItem->setRect(0,0,50,50);
    rectItem->setBrush(Qt::green);
    rectItem->setPen(QColor(255,0,0));
    scene.addItem(rectItem);

    QRect rect = scene.sceneRect().toAlignedRect();
    QImage image(rect.size(), QImage::Format_ARGB32);
    image.fill(Qt::transparent);
    QPainter painter(&image);
    scene.render(&painter);
    image.save("scene.png", "PNG");

    return 0;
}

