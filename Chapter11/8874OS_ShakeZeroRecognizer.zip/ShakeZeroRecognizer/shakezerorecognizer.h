#ifndef SHAKEZERORECOGNIZER_H
#define SHAKEZERORECOGNIZER_H

#include <QtSensors>

class ShakeZeroRecognizer : public QSensorGestureRecognizer
{
    Q_OBJECT
public:
    ShakeZeroRecognizer(QObject *parent = 0) 
      : QSensorGestureRecognizer(parent)
      , m_active(false)
    {}

    virtual ~ShakeZeroRecognizer() {}

public:
    QString id() const
    {
        return QString("MySensors.shakeZero");
    }

    bool isActive()
    {
        return m_active;
    }

protected:
    void create()
    {
        m_sensor = new QTiltSensor(this);
        m_sensor->setSkipDuplicates(true);
        connect(m_sensor, SIGNAL(readingChanged()), this, SLOT(checkReading()));
    }

    bool start()
    {
        m_active = m_sensor->start();
        return m_active;
    }

    bool stop()
    {
        m_sensor->stop();
        m_active = false;
        return m_active;
    }

signals:
    void shakeZero();

private slots:
    void checkReading() {
        QTiltReading *reading = m_sensor->reading();
        if (!reading)
            return;

        const int x = static_cast<int>(reading->xRotation());
        if (m_readings.isEmpty()) {
            m_readings << qMakePair(x, reading->timestamp());
            return;
        } else {
            QPair<int, quint64> lastReading = m_readings.last();
            if ((lastReading.first < 0 && x >= 0)
                    || (lastReading.first >= 0 && x < 0)) {
                m_readings << qMakePair(x, reading->timestamp());
            } else {
                return;
            }
        }

        if (m_readings.count() == 4) {
            if (qAbs(m_readings.last().second - m_readings.first().second) < 2000000) {
                emit shakeZero();
                emit detected("shakeZero");
                m_readings.clear();
            } else {
                m_readings.removeFirst();
            }
        }
    }

private:
    bool m_active;
    QTiltSensor *m_sensor;
    QList<QPair<int, quint64> > m_readings;
};

#endif // SHAKEZERORECOGNIZER_H
