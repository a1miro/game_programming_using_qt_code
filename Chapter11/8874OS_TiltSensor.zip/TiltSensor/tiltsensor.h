#ifndef TILTSENSOR_H
#define TILTSENSOR_H

#include <QMainWindow>

class QTiltSensor;
class MyTiltFilter;

namespace Ui {
class TiltSensor;
}

class TiltSensor : public QMainWindow
{
    Q_OBJECT

public:
    explicit TiltSensor(QWidget *parent = 0);
    ~TiltSensor();

private slots:
    void checkReading();

private:
    Ui::TiltSensor *ui;
    QTiltSensor *m_sensor;
    MyTiltFilter *m_filter;
};

#endif // TILTSENSOR_H
