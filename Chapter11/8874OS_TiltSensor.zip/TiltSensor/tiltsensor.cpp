#include "tiltsensor.h"
#include "ui_tiltsensor.h"

#include <QTiltSensor>
#include <QTiltReading>
#include <QTiltFilter>
#include <QTimer>

class MyTiltFilter : public QTiltFilter
{
public:
    bool filter(QTiltReading *reading) {
        const qreal xrot = reading->xRotation();
        return (xrot >= 5.0 && xrot <= 10.0);
    }
};

TiltSensor::TiltSensor(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TiltSensor)
{
    ui->setupUi(this);

    m_sensor = new QTiltSensor(this);
    m_filter = new MyTiltFilter;

    // Remove the comment on the next line to enable the filter
    // m_sensor->addFilter(m_filter);

    if (m_sensor->connectToBackend()) {
        if (m_sensor->isFeatureSupported(QSensor::SkipDuplicates)) {
            m_sensor->setSkipDuplicates(true);
            connect(m_sensor, SIGNAL(readingChanged()), this, SLOT(checkReading()));
        } else {
            QTimer *timer = new QTimer(this);
            timer->start(1000);
            connect(timer, SIGNAL(timeout()), this, SLOT(checkReading()));
        }
        m_sensor->start();
    }
}

TiltSensor::~TiltSensor()
{
    delete ui;
    delete m_filter;
}

void TiltSensor::checkReading() {
    if (QTiltReading *reading = m_sensor->reading()) {
        ui->xrotation->setText(QString::number(static_cast<int>(reading->xRotation())));
        ui->yrotation->setText(QString::number(static_cast<int>(reading->yRotation())));
    }
}
