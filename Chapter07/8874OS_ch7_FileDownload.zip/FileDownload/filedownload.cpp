#include "filedownload.h"

#include <QPlainTextEdit>
#include <QNetworkAccessManager>
#include <QPushButton>
#include <QVBoxLayout>
#include <QNetworkReply>

FileDownload::FileDownload(QWidget *parent)
    : QWidget(parent)
{
    m_nam = new QNetworkAccessManager(this);
    m_edit = new QPlainTextEdit;
    QPushButton *button = new QPushButton("Load File");
    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(m_edit);
    layout->addWidget(button);
    setLayout(layout);

    connect(button, &QPushButton::clicked, this, &FileDownload::startDownload);
    connect(m_nam, &QNetworkAccessManager::finished, this, &FileDownload::downloadFinished);
}

FileDownload::~FileDownload()
{

}

void FileDownload::startDownload() {
    m_nam->get(QNetworkRequest(QUrl("http://localhost/versions.txt")));
}

void FileDownload::downloadFinished(QNetworkReply *reply) {
    if (reply->error()) {
        const QString error = reply->errorString();
        m_edit->setPlainText(error);
        return;
    }

    const QByteArray content = reply->readAll();
    m_edit->setPlainText(content);
    reply->deleteLater();
}
