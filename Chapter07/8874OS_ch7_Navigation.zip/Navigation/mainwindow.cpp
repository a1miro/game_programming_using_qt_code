#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_nam(new QNetworkAccessManager(this))
    , m_reply(0)
{
    ui->setupUi(this);
    connect(ui->search, SIGNAL(clicked()), this, SLOT(sendRequest()));
    connect(m_nam, SIGNAL(finished(QNetworkReply*)), this, SLOT(finished(QNetworkReply*)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::sendRequest()
{
    if (m_reply != 0 && m_reply->isRunning())
        m_reply->abort();
    ui->result->clear();

    QUrlQuery query;
    query.addQueryItem(QStringLiteral("sensor"), QStringLiteral("false"));
    query.addQueryItem(QStringLiteral("language"), QStringLiteral("en"));
    query.addQueryItem(QStringLiteral("units"), QStringLiteral("metric"));
    query.addQueryItem(QStringLiteral("origins"), ui->from->text());
    query.addQueryItem(QStringLiteral("destinations"), ui->to->text());
    query.addQueryItem(QStringLiteral("mode"), ui->vehicle->currentText());

    QUrl url(QStringLiteral("http://maps.googleapis.com/maps/api/distancematrix/json"));
    url.setQuery(query);
    m_reply = m_nam->get(QNetworkRequest(url));
}

void MainWindow::finished(QNetworkReply *reply)
{
    if (m_reply != reply) {
        reply->deleteLater();
        return;
    }

    m_reply = 0;
    if (reply->error()) {
        ui->result->setPlainText(reply->errorString());
        reply->deleteLater();
        return;
    }

    const QByteArray content = reply->readAll();
    QJsonDocument doc = QJsonDocument::fromJson(content);
    if (doc.isNull() || !doc.isObject()) {
        ui->result->setPlainText("Error while reading the JSON file.");
        reply->deleteLater();
        return;
    }

    QJsonObject obj = doc.object();
    QVariantList origins = obj.value("origin_addresses").toArray().toVariantList();
    QVariantList destinations = obj.value("destination_addresses").toArray().toVariantList();

    for (int i = 0; i < origins.count(); ++i) {
        for (int j = 0; j < destinations.count(); ++j) {
            QString output;
            output += QString("From:").leftJustified(10, ' ') + origins.at(i).toString() + "\n";
            output += QString("To:").leftJustified(10, ' ') + destinations.at(j).toString() + "\n";

            // get distance and duration
            QJsonObject data = obj.value("rows").toArray().at(i).toObject().value("elements").toArray().at(j).toObject();
            QString status = data.value("status").toString();
            if (status == "OK") {
                output += QString("Distance:").leftJustified(10, ' ') + data.value("distance").toObject().value("text").toString() + "\n";
                output += QString("Duration:").leftJustified(10, ' ') + data.value("duration").toObject().value("text").toString() + "\n";
            } else if (status == "NOT_FOUND") {
                output += "Origin and/or destination of this pairing could not be geocoded.\n";
            } else if (status == "ZERO_RESULTS") {
                output += "No route could be found.\n";
            } else {
                output += "Unknown error.\n";
            }

            output += QString("\n").fill('=', 35) + "\n\n";

            ui->result->moveCursor(QTextCursor::End);
            ui->result->insertPlainText(output);
        }
    }
    reply->deleteLater();
}
